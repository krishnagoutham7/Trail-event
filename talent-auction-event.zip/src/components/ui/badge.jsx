export function Badge({ children, className }) {
  return <span className={`bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs ${className}`}>{children}</span>;
}
