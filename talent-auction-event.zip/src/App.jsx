import React from "react";
import { Card, CardContent } from "./components/ui/card";
import { Badge } from "./components/ui/badge";

const teams = [
  {
    name: "Team Alpha",
    bidAmount: 85,
    members: ["Canva Designer", "Excel Pro", "Public Speaker"]
  },
  {
    name: "Team Bravo",
    bidAmount: 90,
    members: ["Creative Thinker", "Video Editor", "Logistics Planner"]
  },
  {
    name: "Team Charlie",
    bidAmount: 78,
    members: ["HR Specialist", "Digital Marketer", "Team Builder"]
  },
  {
    name: "Team Delta",
    bidAmount: 82,
    members: ["Problem Solver", "Strategist", "Quick Learner"]
  },
  {
    name: "Team Echo",
    bidAmount: 88,
    members: ["Meme Master", "Creative Writer", "Time Manager"]
  }
];

export default function App() {
  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold text-center">Talent Auction Event</h1>
      <p className="text-center text-gray-600">Showcasing teams and their talent investments</p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {teams.map((team, index) => (
          <Card key={index} className="rounded-2xl shadow-md p-4">
            <CardContent>
              <h2 className="text-xl font-semibold mb-2">{team.name}</h2>
              <p className="text-sm mb-2">Bid Amount: <span className="font-medium">{team.bidAmount} coins</span></p>
              <div className="flex flex-wrap gap-2">
                {team.members.map((member, idx) => (
                  <Badge key={idx} className="text-sm">{member}</Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
